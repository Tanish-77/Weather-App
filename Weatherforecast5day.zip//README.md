# 5 day weather forcast - WIP
Current WIP
A slightly larger app using real API queries and React.JS

Created using:
* [OpenWeatherMap](https://openweathermap.org/) - Using their 5 day/3 hour API 

:sunny: :umbrella: :cloud: 
